




function sum(){


    console.log("hello");
}


function doWork(a = 0, b = 0) {

    // num1 = a;
    // num2 = b;

    // num3 = num1 + num2;
    num3 = a + b;

    console.log(num3);

}

doWork(8, 10);



// name = "Khurram";
// contact = 3384938493;
// city = "FSD";


name = "Sultan";

name = "new value";

 num1 = 8;


 num2 = 30;

num3 = num1 + num2 * 10;

// console.log(name);
// console.log(num2);

// console.warn("Barish horahi ha");

// // alert(num1);
// // alert(num2);
// // alert(num3);